package com.demo.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.demo.domine.Employee;
@Component
public interface EmployeeDao {
	Employee addEmployee(Employee emp);

	Employee updateEmployee(Employee emp);

	String deleteEmployee(int empid);

	Employee getEmployee(int empid);

	List<Employee> getAllEmployee();
}
