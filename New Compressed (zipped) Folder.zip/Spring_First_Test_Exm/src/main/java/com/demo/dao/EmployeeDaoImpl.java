package com.demo.dao;

import java.util.List;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Repository;

import com.demo.domine.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@PersistenceContext
	EntityManager entity;

	@Override
	public Employee addEmployee(Employee emp) {
		entity.persist(emp);
		return entity.find(Employee.class, emp.getEmpid());
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		return entity.merge(emp);
	}

	@Override
	public String deleteEmployee(int empid) {
		Employee dtl = entity.find(Employee.class, empid);
		if (dtl != null) {
			entity.remove(dtl);
			return "Deleted successfully";
		}
		else {
			return "Not found ";
		}
	}

	@Override
	public Employee getEmployee(int empid) {
		Employee otg=entity.find(Employee.class, empid);
		return otg;
	}

	@Override
	public List<Employee> getAllEmployee() {
		TypedQuery<Employee>tq=entity.createQuery("select e from Employee e",Employee.class);
		List<Employee>li=tq.getResultList();
		return li;
	}

}
