package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.dao.EmployeeDao;
import com.demo.domine.Employee;

@Transactional
@Service
public class EmployeeServiceImpli implements EmployeeService {

	@Autowired
	EmployeeDao dao;
	
	@Override
	public Employee addEmployee(Employee emp) {
		return dao.addEmployee(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		return dao.updateEmployee(emp);
	}

	@Override
	public String deleteEmployee(int empid) {
		return dao.deleteEmployee(empid);
	}

	@Override
	public Employee getEmployee(int empid) {
		return dao.getEmployee(empid);
	}

	@Override
	public List<Employee> getAllEmployee() {
		return dao.getAllEmployee();
	}

}
