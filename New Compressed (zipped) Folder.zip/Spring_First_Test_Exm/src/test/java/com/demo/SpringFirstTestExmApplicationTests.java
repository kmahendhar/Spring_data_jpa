package com.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.hibernate.service.ServiceRegistry;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.demo.domine.Employee;
import com.demo.service.EmployeeService;

@SpringBootTest
class SpringFirstTestExmApplicationTests {
    @Autowired
	EmployeeService service;
    @Test
	public void testAddEmployee() {

		Employee emp = new Employee(12, "krsna", 9999, "vrindha");
		service.addEmployee(emp);
		assertEquals(emp.getEmpname(), "krsna");
	}

}
